import React, { useState, useEffect } from 'react';
import SockJS from 'sockjs-client';
import { Client } from '@stomp/stompjs';import { NotificationContainer, NotificationManager } from 'react-notifications';
import 'react-notifications/lib/notifications.css';
import BASE_URL from '../Pages/Service/baseUrl';

const NotificationComponent = () => {
    const [notifications, setNotifications] = useState([]);
    const [reports, setReports] = useState([]);
  
    useEffect(() => {
      const socket = new SockJS('/ws');
    const stompClient = Stomp.over(socket);

    const onConnect = (frame) => {
      console.log('Connected: ' + frame);

      // Subscribe to /topic/notifications
      stompClient.subscribe('/topic/notifications', (notification) => {
        console.log('Received notification:', JSON.parse(notification.body));
        const notificationData = JSON.parse(notification.body);
        console.log(notificationData.email);
        handleNotification(notificationData);
      });

      // Subscribe to /topic/reports
      stompClient.subscribe('/topic/reports', (message) => {
        console.log('Received report notification:', JSON.parse(message.body));
        const reportData = JSON.parse(message.body);
        console.log(reportData); // Checking
        handleReportNotification(reportData);
      });
    };

    const onError = (frame) => {
      console.error('Broker reported error: ' + frame.headers['message']);
      console.error('Additional details: ' + frame.body);
    };

    stompClient.connect({}, onConnect, onError);

    // Clean up function to deactivate the client when the component unmounts
    return () => {
      if (stompClient) {
        stompClient.disconnect(() => {
          console.log('Disconnected');
        });
      }
    };
  }, [])
  
    const handleNotification = (notification) => {
      setNotifications((prevNotifications) => [...prevNotifications, notification]);
      showNotification(notification);
      
    };
    const handleReportNotification = (report) => {
      setReports([...reports, report]);
      showReportNotification(report);    };
  
    const showNotification = (notification) => {
        const message = `${notification.name} (${notification.email}) wants to join with us.`;
        NotificationManager.info(message, 'Notification');
      };
    
      const showReportNotification = (report) => {
        const message = `Report: ${report.title}. ${report.reportedByName} reported to ${report.reportedToId}.`;
        NotificationManager.warning(message, 'Report Notification');
      };
  return <NotificationContainer />;
};

export default NotificationComponent;
